const si = require('systeminformation');
const WebSocket = require('ws');
const zlib = require('zlib');

const args = process.argv.slice(2);
const port = args[args.indexOf('-port') + 1];
const uuid = args[args.indexOf('-pluginUUID') + 1];
const socket = new WebSocket('ws://localhost:' + port);

const DEFAULTS = {
  'com.kruton.vitals.cpu': { label: 'CPU', color: [0, 255, 204] },
  'com.kruton.vitals.ram': { label: 'RAM', color: [123, 97, 255] },
  'com.kruton.vitals.gpu': { label: 'GPU', color: [255, 149, 0] },
};

let instances = {};

socket.on('open', () => {
  socket.send(JSON.stringify({ event: 'registerPlugin', uuid }));
});

socket.on('message', (data) => {
  const msg = JSON.parse(data);
  if (msg.event === 'willAppear' || msg.event === 'didReceiveSettings') {
    const def = DEFAULTS[msg.action] || {};
    const settings = msg.payload.settings || {};
    const hexColor = settings.customColor;
    instances[msg.context] = {
      action: msg.action,
      name: settings.customName || '',
      color: hexColor ? hexToRgb(hexColor) : (def.color || [0, 255, 204]),
    };
  }
  if (msg.event === 'willDisappear') delete instances[msg.context];
});

function hexToRgb(hex) {
  const r = parseInt(hex.slice(1,3),16);
  const g = parseInt(hex.slice(3,5),16);
  const b = parseInt(hex.slice(5,7),16);
  return [r,g,b];
}

// ── Pure-JS PNG encoder ───────────────────────────────────────────────────────
function makePng(width, height, getPixel) {
  // getPixel(x, y) -> [r, g, b, a]
  const rows = [];
  for (let y = 0; y < height; y++) {
    const row = Buffer.alloc(1 + width * 4);
    row[0] = 0; // filter type: None
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = getPixel(x, y);
      row[1 + x*4 + 0] = r;
      row[1 + x*4 + 1] = g;
      row[1 + x*4 + 2] = b;
      row[1 + x*4 + 3] = a;
    }
    rows.push(row);
  }
  const raw = Buffer.concat(rows);
  const compressed = zlib.deflateSync(raw, { level: 1 });

  function crc32(buf) {
    let c = 0xFFFFFFFF;
    for (const byte of buf) {
      c ^= byte;
      for (let i = 0; i < 8; i++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  function chunk(type, data) {
    const tBuf = Buffer.from(type);
    const lenBuf = Buffer.alloc(4); lenBuf.writeUInt32BE(data.length);
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crc32(Buffer.concat([tBuf, data])));
    return Buffer.concat([lenBuf, tBuf, data, crcBuf]);
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;  // bit depth
  ihdr[9] = 6;  // RGBA
  ihdr[10] = ihdr[11] = ihdr[12] = 0;

  const sig = Buffer.from([137,80,78,71,13,10,26,10]);
  const png = Buffer.concat([sig, chunk('IHDR', ihdr), chunk('IDAT', compressed), chunk('IEND', Buffer.alloc(0))]);
  return png;
}

// ── Pixel-level renderer ──────────────────────────────────────────────────────
function renderGauge(pct, color, label) {
  const W = 144, H = 144;
  const CX = 72, CY = 72, R = 52, LW = 12;
  const isHot = pct > 80;
  const [cr, cg, cb] = isHot ? [255, 68, 68] : color;

  // Build a pixel buffer: Float32 RGBA accumulator for antialiasing
  const buf = new Float32Array(W * H * 4); // r,g,b,a per pixel

  function blendPixel(x, y, r, g, b, a) {
    if (x < 0 || x >= W || y < 0 || y >= H) return;
    const i = (y * W + x) * 4;
    const sa = a / 255;
    const da = buf[i+3];
    const oa = sa + da * (1 - sa);
    if (oa < 1e-6) return;
    buf[i+0] = (r * sa + buf[i+0] * da * (1-sa)) / oa;
    buf[i+1] = (g * sa + buf[i+1] * da * (1-sa)) / oa;
    buf[i+2] = (b * sa + buf[i+2] * da * (1-sa)) / oa;
    buf[i+3] = oa;
  }

  // Draw a thick arc with antialiasing by distance to arc centreline
  function drawArc(cx, cy, radius, lw, startAngle, endAngle, r, g, b) {
    const half = lw / 2;
    const sweep = endAngle - startAngle;
    const steps = Math.max(300, Math.ceil(Math.abs(sweep) * radius * 2));
    for (let i = 0; i <= steps; i++) {
      const angle = startAngle + (i / steps) * sweep;
      const ax = cx + radius * Math.cos(angle);
      const ay = cy + radius * Math.sin(angle);
      const ir = Math.floor(half) + 2;
      for (let dy = -ir; dy <= ir; dy++) {
        for (let dx = -ir; dx <= ir; dx++) {
          const px = Math.round(ax) + dx;
          const py = Math.round(ay) + dy;
          const dist = Math.sqrt((ax-px)**2 + (ay-py)**2);
          const cov = Math.max(0, Math.min(1, half - dist + 0.75));
          if (cov > 0) blendPixel(px, py, r, g, b, cov * 255);
        }
      }
    }
  }

  // Draw a character using a simple 5x7 bitmap font
  const FONT = {
    '0':['01110','10001','10011','10101','11001','10001','01110'],
    '1':['00100','01100','00100','00100','00100','00100','01110'],
    '2':['01110','10001','00001','00010','00100','01000','11111'],
    '3':['11111','00010','00100','00010','00001','10001','01110'],
    '4':['00010','00110','01010','10010','11111','00010','00010'],
    '5':['11111','10000','11110','00001','00001','10001','01110'],
    '6':['00110','01000','10000','11110','10001','10001','01110'],
    '7':['11111','00001','00010','00100','01000','01000','01000'],
    '8':['01110','10001','10001','01110','10001','10001','01110'],
    '9':['01110','10001','10001','01111','00001','00010','01100'],
    '%':['11000','11001','00010','00100','01000','10011','00011'],
    'C':['01110','10001','10000','10000','10000','10001','01110'],
    'P':['11110','10001','10001','11110','10000','10000','10000'],
    'U':['10001','10001','10001','10001','10001','10001','01110'],
    'R':['11110','10001','10001','11110','10100','10010','10001'],
    'A':['00100','01010','10001','11111','10001','10001','10001'],
    'M':['10001','11011','10101','10001','10001','10001','10001'],
    'G':['01110','10001','10000','10111','10001','10001','01111'],
  };

  function drawText(text, cx, cy, scale, r, g, b) {
    const chars = text.toUpperCase().split('');
    const cw = 5 * scale + scale; // char width + spacing
    const totalW = chars.length * cw - scale;
    let x = Math.round(cx - totalW / 2);
    for (const ch of chars) {
      const bmp = FONT[ch];
      if (!bmp) { x += cw; continue; }
      for (let row = 0; row < 7; row++) {
        for (let col = 0; col < 5; col++) {
          if (bmp[row][col] === '1') {
            for (let sy = 0; sy < scale; sy++)
              for (let sx = 0; sx < scale; sx++)
                blendPixel(x + col*scale + sx, cy + row*scale + sy, r, g, b, 255);
          }
        }
      }
      x += cw;
    }
  }

  const START = 0.75 * Math.PI;
  const SWEEP = 1.5 * Math.PI;

  // Track arc
  drawArc(CX, CY, R, LW, START, START + SWEEP, 45, 45, 45);
  // Progress arc
  if (pct > 0) {
    drawArc(CX, CY, R, LW, START, START + (pct/100)*SWEEP, cr, cg, cb);
  }

  // Percentage text (large, centred)
  const pctStr = Math.round(pct) + '%';
  drawText(pctStr, CX, CY - 14, 3, 255, 255, 255);

  // Label text below
  drawText(label, CX, CY + 14, 2, cr, cg, cb);

  // Convert float buffer to PNG pixels
  return makePng(W, H, (x, y) => {
    const i = (y * W + x) * 4;
    return [
      Math.round(buf[i+0]),
      Math.round(buf[i+1]),
      Math.round(buf[i+2]),
      Math.round(buf[i+3] * 255),
    ];
  });
}

async function update() {
  if (Object.keys(instances).length === 0) return;

  let load, mem, gpu;
  try {
    [load, mem, gpu] = await Promise.all([si.currentLoad(), si.mem(), si.graphics()]);
  } catch(e) { return; }

  const vals = {
    'com.kruton.vitals.cpu': load.currentLoad || 0,
    'com.kruton.vitals.ram': mem.total > 0 ? (mem.active / mem.total) * 100 : 0,
    'com.kruton.vitals.gpu': gpu.controllers?.[0]?.utilizationGpu || 0,
  };

  for (const [ctx, cfg] of Object.entries(instances)) {
    const v = vals[cfg.action];
    if (v === undefined) continue;
    const def = DEFAULTS[cfg.action] || { label: '?' };
    const label = cfg.name || def.label;
    const png = renderGauge(v, cfg.color, label);
    const image = 'data:image/png;base64,' + png.toString('base64');
    socket.send(JSON.stringify({ event: 'setImage', context: ctx, payload: { image } }));
  }
}

setInterval(update, 2000);
